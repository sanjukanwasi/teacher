<form class="herald-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
	<input name="s" class="herald-search-input" type="text" value="" placeholder="<?php echo esc_attr( __herald('search_placeholder') ); ?>" /><button type="submit" class="herald-search-submit"></button>
</form>