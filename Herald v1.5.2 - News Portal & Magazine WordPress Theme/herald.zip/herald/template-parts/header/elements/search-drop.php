<div class="herald-menu-popup-search">
<span class="fa fa-search"></span>
	<div class="herald-in-popup">
		<?php get_search_form(); ?>
	</div>
</div>