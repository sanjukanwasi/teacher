<?php

// ads

td_demo_media::add_image_to_media_gallery('td_medicine_post_ad',                 "http://demo_content.tagdiv.com/Newspaper_6/medicine/ad.jpg");
td_demo_media::add_image_to_media_gallery('td_medicine_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/medicine/ad-sidebar.jpg");

