<div class="herald-ovrld">

<?php get_template_part('template-parts/page/head'); ?>
<?php get_template_part('template-parts/page/fimg'); ?>

</div>