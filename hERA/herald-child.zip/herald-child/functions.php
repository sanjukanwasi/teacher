<?php 

/* 
	This is Herald Child Theme functions file
	You can use it to modify specific features and styling of Herald Theme
*/	

add_action( 'after_setup_theme', 'herald_child_theme_setup', 99 );

function herald_child_theme_setup(){
	add_action('wp_enqueue_scripts', 'herald_child_load_scripts');
}

function herald_child_load_scripts() {	
	wp_register_style('herald_child_load_scripts', trailingslashit(get_stylesheet_directory_uri()).'style.css', false, HERALD_THEME_VERSION, 'screen');
	wp_enqueue_style('herald_child_load_scripts');
}


?>