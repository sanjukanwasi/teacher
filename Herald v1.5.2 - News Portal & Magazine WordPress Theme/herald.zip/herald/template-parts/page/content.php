<div class="entry-content herald-entry-content">
	<?php the_content(); ?>
</div>