<?php
/**
 * Created by ra on 6/13/2015.
 */


//logo
td_demo_media::add_image_to_media_gallery('td_pic_logo',                'http://demo_content.tagdiv.com/Newspaper_6/sport/sport-logo.png');

td_demo_media::add_image_to_media_gallery('td_pic_3',                   "http://demo_content.tagdiv.com/Newspaper_6/sport/3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_4',                   "http://demo_content.tagdiv.com/Newspaper_6/sport/4.jpg");