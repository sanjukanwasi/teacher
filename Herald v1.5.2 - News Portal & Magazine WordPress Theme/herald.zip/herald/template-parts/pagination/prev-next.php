<nav class="herald-pagination">
	<div class="herald-next">
		<?php next_posts_link( __herald( 'older_entries' ) ); ?>
	</div>
	<div class="herald-prev">
		<?php previous_posts_link( __herald( 'newer_entries' ) ); ?>
	</div>
</nav>