<header class="entry-header">
	<?php the_title( '<h1 class="entry-title h1">', '</h1>' ); ?>
</header>