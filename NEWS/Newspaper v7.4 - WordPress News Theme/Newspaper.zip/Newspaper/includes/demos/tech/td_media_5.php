<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/tech/p3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/Newspaper_6/tech/p4.jpg");

//logo
td_demo_media::add_image_to_media_gallery('td_pic_logo',                'http://demo_content.tagdiv.com/Newspaper_6/tech/tech-header.png');


