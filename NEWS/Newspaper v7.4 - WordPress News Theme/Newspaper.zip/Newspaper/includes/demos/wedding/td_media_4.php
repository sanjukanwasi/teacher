<?php

// post photos
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/Newspaper_6/wedding/p4.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p5',                  "http://demo_content.tagdiv.com/Newspaper_6/wedding/p5.jpg");

// smartlist photos
td_demo_media::add_image_to_media_gallery('td_pic_s1',                  "http://demo_content.tagdiv.com/Newspaper_6/wedding/s1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_s2',                  "http://demo_content.tagdiv.com/Newspaper_6/wedding/s2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_s3',                  "http://demo_content.tagdiv.com/Newspaper_6/wedding/s3.jpg");
